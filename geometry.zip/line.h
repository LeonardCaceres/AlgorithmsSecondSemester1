#pragma once
#ifndef LINE_H
#define LINE_H
#include "ishape.h"
#include "point.h"
#include "vector.h"

namespace geometry {
class Line : public IShape {
 public:
  Point a_l_;
  Point b_l_;
  Vector ab_l_;
  Line();
  Line(const Point& a, const Point& b);
  Line& Move(const Vector& first) override;
  bool ContainsPoint(const Point& that) const override;
  bool CrossesSegment(const Segment& segment) const override;
  Line* Clone() const override;
  std::string ToString() const override;
};
}  // namespace geometry

#endif