#include "../circle.h"
#include "../vector.h"
#include "../point.h"
#include "../segment.h"
#include "../ishape.h"
#include "../polygon.h"
#include "../line.h"
#include "../ray.h"
using geometry::Point;
using geometry::Segment;
using geometry::Vector;
#include <string>

Point::Point() {
  x_p_ = 0;
  y_p_ = 0;
}

Point::Point(const int64_t& a, const int64_t& b) {
  x_p_ = a;
  y_p_ = b;
}

Point::Point(const Point& a) {
  x_p_ = a.x_p_;
  y_p_ = a.y_p_;
}

Point& Point::operator=(const Point& other) {
  x_p_ = other.x_p_;
  y_p_ = other.y_p_;
  return *this;
}

Point& Point::Move(const Vector& first) {
  x_p_ += first.x_v_;
  y_p_ += first.y_v_;
  return *this;
}

bool Point::ContainsPoint(const Point& that) const {
  return that == *this;
}

bool Point::CrossesSegment(const Segment& segment) const {
  Vector ac(segment.a_s_, *this);
  Vector cb(*this, segment.b_s_);
  return ScalarPr(ac, cb) >= 0 && VectorPr(ac, cb) == 0;
}

Point* Point::Clone() const {
  return new Point(x_p_, y_p_);
}

std::string Point::ToString() const {
  std::string a("Point(");
  a += std::to_string(x_p_);
  a += ", ";
  a += std::to_string(y_p_);
  a += ")";
  return a;
}

bool Point::operator==(const Point& other) const {
  return x_p_ == other.x_p_ && y_p_ == other.y_p_;
}

Vector Point::operator-(const Point& a) const {
  Vector copy;
  copy.x_v_ = this->x_p_ - a.x_p_;
  copy.y_v_ = this->y_p_ - a.y_p_;
  return copy;
}