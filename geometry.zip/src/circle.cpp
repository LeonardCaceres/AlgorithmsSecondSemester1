#include "../circle.h"
#include "../vector.h"
#include "../point.h"
#include "../line.h"
#include "../segment.h"
#include "../ishape.h"
#include "../polygon.h"
#include "../ray.h"
#include <cmath>
using geometry::Point;
using geometry::Segment;
using geometry::Vector;
using geometry::Circle;
using geometry::Line;
#include <string>

Circle::Circle(const Point& a, const int64_t& r) {
  a_c_ = a;
  r_c_ = r;
}

Circle& Circle::Move(const Vector& first) {
  a_c_.Move(first);
  return *this;
}

double Lenght(const Point& a, const Point& b) {
  return std::sqrt((a.x_p_ - b.x_p_) * (a.x_p_ - b.x_p_) + (a.y_p_ - b.y_p_) * (a.y_p_ - b.y_p_));
}

bool Circle::ContainsPoint(const Point& that) const {
  double epsilon = 0.000001;
  return ((that.x_p_ - a_c_.x_p_) * (that.x_p_ - a_c_.x_p_) + (that.y_p_ - a_c_.y_p_) * (that.y_p_ - a_c_.y_p_)) - r_c_ * r_c_ <= epsilon;
}

bool Circle::ContainsPointStrictly(const Point& that) const {
  return ((that.x_p_ - a_c_.x_p_) * (that.x_p_ - a_c_.x_p_) + (that.y_p_ - a_c_.y_p_) * (that.y_p_ - a_c_.y_p_)) - r_c_ * r_c_ < 0;
}

double LenghtPointToLine(const Line& line, const Point& a) {
  if (line.ContainsPoint(a)) {
    return 0;
  }
  Vector vec(a, line.a_l_);
  return std::abs((VectorPr(vec, line.ab_l_)) / (Lenght(line.a_l_, line.b_l_)));
}

bool Circle::CrossesSegment(const Segment& segment) const {
  Line line(segment.a_s_, segment.b_s_);
  double epsilon = 0.000000001;
  if ((segment.a_s_.x_p_ - a_c_.x_p_) * (segment.a_s_.x_p_ - a_c_.x_p_) +
    (segment.a_s_.y_p_ - a_c_.y_p_) * (segment.a_s_.y_p_ - a_c_.y_p_) == r_c_ * r_c_) {
    return true;
  }
  if ((segment.b_s_.x_p_ - a_c_.x_p_) * (segment.b_s_.x_p_ - a_c_.x_p_) +
          (segment.b_s_.y_p_ - a_c_.y_p_) * (segment.b_s_.y_p_ - a_c_.y_p_) ==
      r_c_ * r_c_) {
    return true;
  }
  if (ContainsPoint(segment.a_s_) && !ContainsPoint(segment.b_s_)) {
    return true;
  }
  if (ContainsPoint(segment.b_s_) && !ContainsPoint(segment.a_s_)) {
    return true;
  }
  if (ContainsPointStrictly(segment.b_s_) && ContainsPointStrictly(segment.a_s_)) {
    return false;
  }
  return (LenghtPointToLine(line, a_c_) - r_c_ < epsilon);
}

Circle* Circle::Clone() const {
  return new Circle(a_c_, r_c_);
}

std::string Circle::ToString() const {
  std::string a("Circle(");
  a += a_c_.ToString() + ", " + std::to_string(r_c_) + ")";
  return a;
}