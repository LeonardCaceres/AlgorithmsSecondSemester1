#include "../circle.h"
#include "../vector.h"
#include "../point.h"
#include "../segment.h"
#include "../ishape.h"
#include "../polygon.h"
#include "../line.h"
#include "../ray.h"
using geometry::Point;
using geometry::Segment;
using geometry::Vector;
using geometry::Polygon;
using geometry::Ray;
#include <string>

Polygon& Polygon::operator=(std::vector<Point> arr) {
  arr_.clear();
  for (uint64_t i = 0; i < arr.size(); ++i) {
    arr_.push_back(arr[i]);
  }
  return *this;
}

Polygon::Polygon(std::vector<Point>&& arr) {
  arr_ = arr;
}

Polygon::Polygon(const std::vector<Point>& arr) {
  arr_ = arr;
}

Polygon& Polygon::Move(const Vector& first) {
  for (uint64_t i = 0; i < this->arr_.size(); ++i) {
    arr_[i].Move(first);
  }
  return *this;
}

Polygon* Polygon::Clone() const {
  return new Polygon(arr_);
}

std::string Polygon::ToString() const {
  std::string a("Polygon(");
  for (uint64_t i = 0; i < arr_.size(); ++i) {
    a += arr_[i].ToString() + ", ";
  }
  a.pop_back();
  a.pop_back();
  a += ")";
  return a;
}

bool PointInSegment(const Point& o, const Segment& ab) {
  Vector oa(o, ab.a_s_);
  Vector ob(o, ab.b_s_);
  return (VectorPr(oa, ob) == 0 && ScalarPr(oa, ob) < 0);
}

bool PointInRay(const Ray& ray, const Point& b) {
  Vector ob(ray.a_r_, b);
  return (ScalarPr(ray.ab_r_, ob) >= 0 && VectorPr(ray.ab_r_, ob) == 0);
}

bool IsSegmentRay(const Ray& ray, const Segment& ab_seg) {
  Vector oa(ray.a_r_, ab_seg.a_s_), ob(ray.a_r_, ab_seg.b_s_);
  Vector ao(ab_seg.a_s_, ray.a_r_), bo(ab_seg.b_s_, ray.a_r_);
  Vector ab(ab_seg.a_s_, ab_seg.b_s_);
  return ((geometry::Sign(VectorPr(ray.ab_r_, oa)) * geometry::Sign(VectorPr(ray.ab_r_, ob)) < 0) &&
          (geometry::Sign(VectorPr(ao, ab)) * geometry::Sign(VectorPr(ray.ab_r_, ab)) < 0));
}

bool Polygon::ContainsPoint(const Point& that) const {
  Ray ray(that);
  Vector oa(ray.a_r_, arr_[0]);
  Vector ob(ray.a_r_, arr_[1]);
  Segment ab_seg(arr_[0], arr_[1]);
  uint64_t counter = 0;
  bool is_on_the_border = false;
  for (uint64_t i = 1; i < arr_.size(); ++i) {
    if (IsSegmentRay(ray, ab_seg) && (!PointInSegment(ray.a_r_, ab_seg))) {
      counter++;
    } else if (PointInSegment(ray.a_r_, ab_seg)) {
      is_on_the_border = true;
    }
    oa = arr_[i] - ray.a_r_;
    ob = arr_[(i + 1) % arr_.size()] - ray.a_r_;
    ab_seg.a_s_ = arr_[i];
    ab_seg.b_s_ = arr_[(i + 1) % arr_.size()];
  }
  if (IsSegmentRay(ray, ab_seg) && (!PointInSegment(ray.a_r_, ab_seg))) {
    counter++;
  } else if (PointInSegment(ray.a_r_, ab_seg)) {
    is_on_the_border = true;
  }
  Point b(arr_[arr_.size() - 1].x_p_, arr_[arr_.size() - 1].y_p_);
  Point a(arr_[0].x_p_, arr_[0].y_p_);
  Point c(arr_[1].x_p_, arr_[1].y_p_);
  Vector ba(b, a);
  Vector bc(b, c);
  oa.x_v_ = arr_[arr_.size() - 1].x_p_ - ray.a_r_.x_p_;
  oa.y_v_ = arr_[arr_.size() - 1].y_p_ - ray.a_r_.y_p_;
  Vector oc(ray.a_r_, arr_[1]);
  for (uint64_t i = 0; i < arr_.size(); ++i) {
    if (PointInRay(ray, b)) {
      if (VectorPr(ray.ab_r_, oa) * Sign(VectorPr(ray.ab_r_, oc)) > 0) {
        counter += 2;
      } else if (VectorPr(ray.ab_r_, oa) * VectorPr(ray.ab_r_, oc) < 0) {
        counter++;
      } else if (PointInRay(ray, a) || PointInRay(ray, c)) {
        counter += 0;
      }
    }
    if (ray.a_r_.x_p_ == b.x_p_ && ray.a_r_.y_p_ == b.y_p_) {
      is_on_the_border = true;
    }
    a = b;
    b = c;
    c = arr_[(i + 1) % arr_.size()];
    ba = a - b;
    bc = c - b;
    oa = arr_[i] - ray.a_r_;
    oc = arr_[(i + 2) % arr_.size()] - ray.a_r_;
    oc.y_v_ = arr_[(i + 2) % arr_.size()].y_p_ - ray.a_r_.y_p_;
  }
  if (PointInRay(ray, b)) {
    if (VectorPr(ray.ab_r_, oa) * VectorPr(ray.ab_r_, oc) > 0) {
      counter += 2;
    } else if (VectorPr(ray.ab_r_, oa) * VectorPr(ray.ab_r_, oc) < 0) {
      counter++;
    } else if (PointInRay(ray, a) || PointInRay(ray, c)) {
      counter += 0;
    }
  }
  if (ray.a_r_.x_p_ == b.x_p_ && ray.a_r_.y_p_ == b.y_p_) {
    is_on_the_border = true;
  }
  if (is_on_the_border) {
    counter = 1;
  }
  return counter % 2;
}

bool Polygon::CrossesSegment(const Segment& segment) const {
  Segment polygon_seg;
  for (uint64_t i = 0; i < arr_.size(); ++i) {
    polygon_seg.a_s_ = arr_[i];
    polygon_seg.b_s_ = arr_[(i + 1) % arr_.size()];
    if (polygon_seg.CrossesSegment(segment)) {
      return true;
    }
  }
  return false;
}