#include "../circle.h"
#include "../vector.h"
#include "../point.h"
#include "../segment.h"
#include "../ishape.h"
#include "../polygon.h"
#include "../ray.h"
#include "../line.h"
using geometry::Point;
using geometry::Segment;
using geometry::Vector;
using geometry::Line;

Segment::Segment() {
  a_s_.x_p_ = 0;
  b_s_.x_p_ = 0;
  a_s_.y_p_ = 0;
  b_s_.y_p_ = 0;
}

Segment::Segment(const Point& a, const Point& b) {
  a_s_ = a;
  b_s_ = b;
}

Segment::Segment(const Segment& ab) {
  a_s_ = ab.a_s_;
  b_s_ = ab.b_s_;
}

Segment& Segment::Move(const Vector& first) {
  a_s_.Move(first);
  b_s_.Move(first);
  return *this;
}

bool PointInSegment(const Point& a, const Point& b, const Point& c) {
  Vector ab(a, b);
  Vector bc(b, c);
  return VectorPr(ab, bc) == 0 && ScalarPr(ab, bc) >= 0;
}

bool Segment::ContainsPoint(const Point& that) const {
  Vector ac(this->a_s_, that);
  Vector cb(that, this->b_s_);
  return ScalarPr(ac, cb) >= 0 && VectorPr(ac, cb) == 0;
}

bool Segment::CrossesSegment(const Segment& segment) const {
  Vector ab(a_s_, b_s_), ac(a_s_, segment.a_s_), ad(a_s_, segment.b_s_);
  Vector cd(segment.a_s_, segment.b_s_), ca(segment.a_s_, a_s_), cb(segment.a_s_, b_s_);
  bool crosses_segment = false;
  if (VectorPr(ab, ac) == 0 && VectorPr(ab, ad) == 0 && VectorPr(cd, ca) == 0 && VectorPr(cd, cb) == 0) {
    if (PointInSegment(segment.a_s_, b_s_, segment.b_s_) || PointInSegment(segment.a_s_, a_s_, segment.b_s_) ||
        PointInSegment(a_s_, segment.a_s_, b_s_) || PointInSegment(a_s_, segment.b_s_, b_s_)) {
      crosses_segment = true;
    }
  } else {
    if ((VectorPr(ab, ac) * VectorPr(ab, ad) <= 0) && (VectorPr(cd, cb) * VectorPr(cd, ca) <= 0)) {
      crosses_segment = true;
    }
  }
  return crosses_segment;
}

Segment* Segment::Clone() const {
  return new Segment(a_s_, b_s_);
}

std::string Segment::ToString() const {
  std::string a("Segment(");
  a += a_s_.ToString() + ", " + b_s_.ToString() + ")";
  return a;
}