#include "../circle.h"
#include "../vector.h"
#include "../point.h"
#include "../segment.h"
#include "../ishape.h"
#include "../polygon.h"
#include "../line.h"
#include "../ray.h"
using geometry::Point;
using geometry::Segment;
using geometry::Vector;
using geometry::Line;
#include <string>

Line::Line() {
  a_l_.x_p_ = 0;
  a_l_.y_p_ = 0;
  b_l_ = a_l_;
  ab_l_.y_v_ = 0;
}

Line::Line(const Point& a, const Point& b) {
  a_l_ = a;
  b_l_ = b;
  ab_l_ = b - a;
}

Line& Line::Move(const Vector& first) {
  a_l_.Move(first);
  b_l_.Move(first);
  return *this;
}

bool Line::ContainsPoint(const Point& that) const {
  Vector ac(this->a_l_, that);
  Vector bc(this->b_l_, that);
  return VectorPr(ac, bc) == 0;
}

bool Line::CrossesSegment(const Segment& segment) const {
  Vector ab(a_l_, segment.a_s_), ac(a_l_, segment.b_s_);
  return Sign(VectorPr(ab_l_, ab)) * Sign(VectorPr(ab_l_, ac)) <= 0;
}

Line* Line::Clone() const {
  return new Line(a_l_, b_l_);
}

std::string Line::ToString() const {
  int64_t x = a_l_.x_p_ - b_l_.x_p_;
  int64_t y = a_l_.y_p_ - b_l_.y_p_;
  int64_t c = (y * a_l_.x_p_ - x * a_l_.y_p_);
  std::string a("Line(");
  a += std::to_string(-y) + ", " + std::to_string(x) + ", " + std::to_string(c) + ")";
  return a;
}