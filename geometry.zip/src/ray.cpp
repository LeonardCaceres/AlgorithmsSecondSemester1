#include "../circle.h"
#include "../vector.h"
#include "../point.h"
#include "../line.h"
#include "../segment.h"
#include "../ishape.h"
#include "../polygon.h"
#include "../ray.h"
using geometry::Point;
using geometry::Segment;
using geometry::Vector;
using geometry::Ray;
#include <string>

Ray::Ray() {
  a_r_.x_p_ = 0;
  b_r_.x_p_ = 0;
  a_r_.y_p_ = 0;
  b_r_.y_p_ = 0;
  ab_r_.x_v_ = 0;
  ab_r_.y_v_ = 0;
}

Ray::Ray(const Point& a) {
  a_r_.x_p_ = a.x_p_;
  b_r_.x_p_ = a.x_p_ + 10000;
  a_r_.y_p_ = a.y_p_;
  b_r_.y_p_ = a.y_p_ + 999;
  ab_r_.x_v_ = 1000;
  ab_r_.y_v_ = 999;
}

Ray::Ray(const Point& a, const Point& b) {
  a_r_ = a;
  b_r_ = b;
  ab_r_.x_v_ = b_r_.x_p_ - a.x_p_;
  ab_r_.y_v_ = b_r_.y_p_ - a.y_p_;
}

Ray& Ray::Move(const Vector& first) {
  a_r_.Move(first);
  b_r_.Move(first);
  return *this;
}

bool Ray::ContainsPoint(const Point& that) const {
  Vector ac(a_r_, that);
  return VectorPr(ab_r_, ac) == 0 && ScalarPr(ab_r_, ac) >= 0;
}

bool Ray::CrossesSegment(const Segment& segment) const {
  Vector ao(segment.a_s_, a_r_), ab(segment.a_s_, segment.b_s_);
  bool is_crosses = false;
  if (Sign(VectorPr(ao, ab)) * Sign(VectorPr(ab_r_, ab)) < 0) {
    is_crosses = true;
  }
  if (ContainsPoint(segment.a_s_) || ContainsPoint(segment.b_s_)) {
    is_crosses = true;
  }
  if (segment.a_s_ == a_r_ || segment.b_s_ == a_r_) {
    is_crosses = true;
  }
  return is_crosses;
}

Ray* Ray::Clone() const {
  return new Ray(a_r_, b_r_);
}

std::string Ray::ToString() const {
  std::string a = "Ray(";
  a += a_r_.ToString();
  a += ", Vector(" + std::to_string(ab_r_.x_v_) + ", " + std::to_string(ab_r_.y_v_) + "))";
  return a;
}