#include "../circle.h"
#include "../vector.h"
#include "../point.h"
#include "../segment.h"
#include "../ishape.h"
#include "../polygon.h"
#include "../ray.h"
#include "../line.h"
#include <cstdint>
using geometry::Vector;
using geometry::Point;

Vector::Vector() {
  x_v_ = 0;
  y_v_ = 0;
}

Vector::Vector(const Point& a, const Point& b) {
  x_v_ = b.x_p_ - a.x_p_;
  y_v_ = b.y_p_ - a.y_p_;
}

Vector::Vector(const Vector& a) {
  x_v_ = a.x_v_;
  y_v_ = a.y_v_;
}

Vector& Vector::operator=(const Vector& other) = default;

Vector operator-(const Vector& other) {
  Vector result;
  result.x_v_ = -other.x_v_;
  result.y_v_ = -other.y_v_;
  return result;
}

Vector operator+(const Vector& other) {
  return other;
}

Vector& Vector::operator+=(const Vector& other) {
  this->x_v_ += other.x_v_;
  this->y_v_ += other.y_v_;
  return *this;
}

Vector& Vector::operator-=(const Vector& other) {
  this->x_v_ -= other.x_v_;
  this->y_v_ -= other.y_v_;
  return *this;
}

Vector operator+(const Vector& other_1, const Vector& other_2) {
  Vector double_vector(other_1);
  double_vector += other_2;
  return double_vector;
}

Vector operator-(const Vector& other_1, const Vector& other_2) {
  Vector double_vector;
  double_vector.x_v_ = other_1.x_v_ - other_2.x_v_;
  double_vector.y_v_ = other_1.y_v_ - other_2.y_v_;
  return double_vector;
}

Vector operator*(const Vector& other_v, const int64_t& other_1) {
  Vector scalar_pr;
  scalar_pr.x_v_ = other_v.x_v_ * other_1;
  scalar_pr.y_v_ = other_v.y_v_ * other_1;
  return scalar_pr;
}

Vector& Vector::operator*=(const int64_t& other) {
  x_v_ *= other;
  y_v_ *= other;
  return *this;
}

Vector& Vector::operator/=(const int64_t& other) {
  x_v_ /= other;
  y_v_ /= other;
  return *this;
}

Vector operator/(const Vector& other_v, const int64_t& other_1) {
  Vector scalar_pr;
  scalar_pr.x_v_ = other_v.x_v_ / other_1;
  scalar_pr.y_v_ = other_v.y_v_ / other_1;
  return scalar_pr;
}

bool Vector::operator==(const Vector& other) const {
  return (x_v_ == other.x_v_) && (y_v_ == other.y_v_);
}

int64_t geometry::ScalarPr(const Vector& first, const Vector& second) {
  return first.x_v_ * second.x_v_ + first.y_v_ * second.y_v_;
}

int64_t geometry::VectorPr(const Vector& first, const Vector& second) {
  return first.x_v_ * second.y_v_ - second.x_v_ * first.y_v_;
}

void Vector::ToString() const {
  std::cout << "Vector(" << x_v_ << ", " << y_v_ << ")";
}

bool Vector::operator!=(const Vector& other) const {
  return !(*this == other);
}

int64_t geometry::Sign(const int64_t& num) {
  int64_t k = -1;
  if (num > 0) {
    k = 1;
  } else if (num == 0) {
    k = 0;
  }
  return k;
}