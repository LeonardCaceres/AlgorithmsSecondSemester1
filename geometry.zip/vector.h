#pragma once
#ifndef VECTOR_H
#define VECTOR_H
#include <iostream>
#include "ishape.h"
#include "point.h"

namespace geometry {
class Vector {
 public:
  int64_t x_v_;
  int64_t y_v_;
  Vector();
  Vector(const Point& a, const Point& b);
  Vector(const Vector& a);  // NOLINT
  Vector& operator=(const Vector& other);  // NOLINT
  bool operator==(const Vector& other) const;
  bool operator!=(const Vector& other) const;
  friend Vector operator-(const Vector& other);
  friend Vector operator+(const Vector& other);
  friend Vector operator-(const Vector& other_1, const Vector& other_2);
  friend Vector operator+(const Vector& other_1, const Vector& other_2);
  friend Vector operator*(const Vector& other_v, const int64_t& other_1);
  friend Vector operator/(const Vector& other_v, const int64_t& other_1);
  Vector& operator+=(const Vector& other);
  Vector& operator-=(const Vector& other);
  Vector& operator*=(const int64_t& other);
  Vector& operator/=(const int64_t& other);
  void ToString() const;
  ~Vector() = default;
};

int64_t ScalarPr(const Vector& first, const Vector& second);
int64_t VectorPr(const Vector& first, const Vector& second);
int64_t Sign(const int64_t& num);
}  // namespace geometry

#endif