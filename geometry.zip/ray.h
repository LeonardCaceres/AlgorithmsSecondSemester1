#pragma once
#ifndef RAY_H
#define RAY_H
#include "ishape.h"
#include "point.h"

namespace geometry {
class Ray : public IShape {
 public:
  Point a_r_;
  Point b_r_;
  Vector ab_r_;
  Ray();
  Ray(const Point& a);  // NOLINT
  Ray(const Point& a, const Point& b);
  Ray(const Ray& op);  // NOLINT
  Ray& Move(const Vector& first) override;
  bool ContainsPoint(const Point& that) const override;
  bool CrossesSegment(const Segment& segment) const override;
  Ray* Clone() const override;
  std::string ToString() const override;
};
}  // namespace geometry

#endif