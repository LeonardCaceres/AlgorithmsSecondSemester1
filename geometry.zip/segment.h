#pragma once
#ifndef SEGMENT_H
#define SEGMENT_H
#include "ishape.h"
#include "point.h"
namespace geometry {

class Segment : public IShape {
 public:
  Point a_s_;
  Point b_s_;
  Segment();
  Segment(const Point& a, const Point& b);
  Segment(const Segment& ab);  // NOLINT
  Segment& Move(const Vector& first) override;
  bool ContainsPoint(const Point& that) const override;
  bool CrossesSegment(const Segment& segment) const override;
  Segment* Clone() const override;
  std::string ToString() const override;
};
}  // namespace geometry
#endif