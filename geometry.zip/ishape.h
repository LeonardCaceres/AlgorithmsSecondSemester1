#pragma once
#ifndef ISHAPE_H
#define ISHAPE_H

#include <iostream>

namespace geometry {
class Point;
class Vector;
class Segment;

class IShape {
 public:
  virtual IShape& Move(const Vector& first) = 0;
  virtual bool ContainsPoint(const Point& that) const = 0;
  virtual bool CrossesSegment(const Segment& segment) const = 0;
  virtual IShape* Clone() const = 0;
  virtual std::string ToString() const = 0;
  virtual ~IShape() = default;
};
}  // namespace geometry
#endif