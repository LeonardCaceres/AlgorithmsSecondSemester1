#pragma once
#ifndef POLYGON_H
#define POLYGON_H
#include "ishape.h"
#include <iostream>
#include <vector>
#include "point.h"

namespace geometry {

class Polygon : public IShape {
 public:
  std::vector<Point> arr_;
  Polygon(std::vector<Point>&& arr);  // NOLINT
  Polygon(const std::vector<Point>& arr);  // NOLINT
  Polygon& Move(const Vector& first) override;
  bool ContainsPoint(const Point& that) const override;
  bool CrossesSegment(const Segment& segment) const override;
  Polygon* Clone() const override;
  std::string ToString() const override;
  Polygon& operator=(std::vector<Point> arr);
};
}  // namespace geometry

#endif