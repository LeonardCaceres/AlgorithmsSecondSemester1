#pragma once
#ifndef POINT_H
#define POINT_H
#include "ishape.h"

namespace geometry {
class Point : public IShape {
 public:
  int64_t x_p_;
  int64_t y_p_;
  Point();
  Point(const int64_t& a, const int64_t& b);
  Point(const Point& a);  // NOLINT
  Point& Move(const Vector& first) override;
  bool ContainsPoint(const Point& that) const override;
  bool CrossesSegment(const Segment& segment) const override;
  Point& operator=(const Point& other);  // NOLINT
  bool operator==(const Point& other) const;
  Point* Clone() const override;
  std::string ToString() const override; 
  Vector operator-(const Point& a) const;
};
}  // namespace geometry

#endif