#pragma once
#ifndef CIRCLE_H
#define CIRCLE_H
#include "ishape.h"
#include "point.h"

namespace geometry {

class Circle : public IShape {
 public:
  Point a_c_;
  int64_t r_c_;
  Circle(const Point& a, const int64_t& r);
  Circle& Move(const Vector& first) override;
  bool ContainsPoint(const Point& that) const override;
  bool CrossesSegment(const Segment& segment) const override;
  Circle* Clone() const override;
  std::string ToString() const override;
  bool ContainsPointStrictly(const Point& that) const;
};
}  // namespace geometry
#endif